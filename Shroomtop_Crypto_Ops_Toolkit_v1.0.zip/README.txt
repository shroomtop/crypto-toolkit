Shroomtop420® Crypto Ops Toolkit v1.0
=====================================

This toolkit includes self-contained, adversarial-grade crypto operations:
- Lightning Network routing daemon
- DeFi airdrop farming scripts
- NFT minting automation
- Cloud hash contract arbitrage bots

Tested on Termux with Zsh + Flask. Works offline with optional Infura/Alchemy keys.

Directories:
- lightning_node/: Configure and run a BTC Lightning node
- defi_farm/: Auto-claim airdrops + yield farm tokens
- nft_minter/: Auto-detect and mint NFTs, auto-post to OpenSea
- hashflip_bot/: Arbitrage miner contracts and maximize mining ROI

All scripts are chmod +x, auto-executing, and widget-launchable in Termux.

-- Shroomtop420® | May 2025